﻿var inra={
"type": "FeatureCollection",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
                                                                                
"features": [
{ "type": "Feature", "properties": { "proprietai": "INRA", "nom": "Station météorologique d'Avignon", "commune": "Avignon (84)", "lieu_dit": "Saint Paul", "INSEE": 84007, "debut_obs": "Janvier 1988", "fin_obs": "Toujours en service", "type": "Automatique", "variables": "Températures, précipitations, humidité, vitesse du vent, direction du vent, humectation, rayonnement", "types_donn": "Numériques", "altitude": 24, "X": 850985.0, "Y": 6315241.4, "latitude": "43,92°N", "longitude": "4,88°E" }, "geometry": { "type": "Point", "coordinates": [ 4.879999766025462, 43.919999795399249 ] } },
{ "type": "Feature", "properties": { "proprietai": "INRA", "nom": "Station météorologique de Salon de Provence", "commune": "Salon de Provence (13)", "lieu_dit": "Le Merle", "INSEE": 13103, "debut_obs": "Juin 1993", "fin_obs": "Toujours en service", "type": "Automatique", "variables": "Températures, précipitations, humidité, vitesse du vent, direction du vent, humectation, rayonnement", "types_donn": "Numériques", "altitude": 68, "X": 860629.5, "Y": 6283241.2, "latitude": "43,63°N", "longitude": "4,99°E" }, "geometry": { "type": "Point", "coordinates": [ 4.98999972975622, 43.630000280699797 ] } }
]
}
